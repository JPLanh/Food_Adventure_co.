import javax.swing.*;

import UI.GUIController;

public class index extends JFrame{

	public static void main(String[] args) {
		mainFrame mainFrame = new mainFrame(800, 600);
	}
}

